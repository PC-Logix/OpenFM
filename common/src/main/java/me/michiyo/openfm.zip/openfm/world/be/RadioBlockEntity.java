package me.michiyo.openfm.world.be;

import me.michiyo.openfm.client.audio.RadioStreamManager;
import me.michiyo.openfm.reg.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.UUID;

public class RadioBlockEntity extends BlockEntity {
    public static final String DEFAULT_COLOR = "0AFF0A";
    public static final String DEFAULT_TEXT  = "OpenFM";

    private UUID ownerUuid = null;
    private boolean locked = false;

    // NEW: explicit playback state
    private boolean playing = false;

    private int volume = 5; // 0..10
    private String streamUrl = "";
    private String screenColor = DEFAULT_COLOR;
    private String screenText = DEFAULT_TEXT;

    private final SimpleContainer inv = new SimpleContainer(1) {
        @Override
        public void setChanged() {
            super.setChanged();
            RadioBlockEntity.this.markDirtyAndSync();
        }
    };

    public RadioBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.RADIO_BE.get(), pos, state);
    }

    private void markDirtyAndSync() {
        setChanged();
        if (level != null && !level.isClientSide) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private static String sanitizeUrl(String url) {
        return (url == null) ? "" : url.trim();
    }

    private static String sanitizeColor(String c) {
        String s = (c == null) ? "" : c.trim();
        if (s.isEmpty()) return DEFAULT_COLOR;
        if (s.startsWith("#")) s = s.substring(1);
        s = s.toUpperCase();
        if (!s.matches("^[0-9A-F]{6}$")) return DEFAULT_COLOR;
        return s;
    }

    private static String sanitizeScreenText(String t) {
        String s = (t == null) ? "" : t;
        if (s.trim().isEmpty()) return DEFAULT_TEXT;
        return s;
    }

    public UUID getOwnerUuid() { return ownerUuid; }

    public void ensureOwner(UUID uuid) {
        if (ownerUuid == null && uuid != null) {
            ownerUuid = uuid;
            markDirtyAndSync();
        }
    }

    public boolean isLocked() { return locked; }

    public void setLocked(boolean locked) {
        this.locked = locked;
        markDirtyAndSync();
    }

    // NEW: playback state accessors
    public boolean isPlaying() { return playing; }

    public void setPlaying(boolean playing) {
        if (this.playing == playing) return;
        this.playing = playing;
        markDirtyAndSync();
    }

    public int getVolume() { return volume; }

    public void setVolume(int v) {
        int nv = clamp(v, 0, 10);
        if (nv == this.volume) return;
        this.volume = nv;
        markDirtyAndSync();
    }

    public String getStreamUrl() { return streamUrl; }

    public void setStreamUrl(String url) {
        String nu = sanitizeUrl(url);
        if (nu.equals(this.streamUrl)) return;
        this.streamUrl = nu;
        markDirtyAndSync();
    }

    public String getScreenColor() { return screenColor; }

    public void setScreenColor(String c) {
        String nc = sanitizeColor(c);
        if (nc.equals(this.screenColor)) return;
        this.screenColor = nc;
        markDirtyAndSync();
    }

    public String getScreenText() { return screenText; }

    public void setScreenText(String t) {
        String nt = sanitizeScreenText(t);
        if (nt.equals(this.screenText)) return;
        this.screenText = nt;
        markDirtyAndSync();
    }

    public SimpleContainer getInventory() { return inv; }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);

        if (ownerUuid != null) tag.putUUID("Owner", ownerUuid);
        tag.putBoolean("Locked", locked);

        // NEW
        tag.putBoolean("Playing", playing);

        tag.putInt("Volume", volume);
        tag.putString("StreamUrl", streamUrl);
        tag.putString("ScreenColor", screenColor);
        tag.putString("ScreenText", screenText);

        CompoundTag invTag = new CompoundTag();
        ItemStack stack = inv.getItem(0);
        if (!stack.isEmpty()) invTag.put("MemoryCard", stack.save(new CompoundTag()));
        tag.put("Inv", invTag);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);

        ownerUuid = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
        locked = tag.getBoolean("Locked");

        // NEW (defaults false if missing)
        playing = tag.getBoolean("Playing");

        volume = clamp(tag.getInt("Volume"), 0, 10);
        streamUrl = sanitizeUrl(tag.getString("StreamUrl"));
        screenColor = sanitizeColor(tag.getString("ScreenColor"));
        screenText = sanitizeScreenText(tag.getString("ScreenText"));

        inv.setItem(0, ItemStack.EMPTY);
        if (tag.contains("Inv")) {
            CompoundTag invTag = tag.getCompound("Inv");
            if (invTag.contains("MemoryCard")) {
                inv.setItem(0, ItemStack.of(invTag.getCompound("MemoryCard")));
            }
        }
    }

    // ---- client audio wiring (RESPECT playing) ----

    private void clientApplyAudioState() {
        if (level == null || !level.isClientSide) return;

        if (!playing) {
            RadioStreamManager.applyState(worldPosition, "", 0);
            return;
        }

        // Only play if configured and valid
        if (streamUrl == null || streamUrl.isEmpty() || volume <= 0) {
            RadioStreamManager.applyState(worldPosition, "", 0);
            return;
        }

        RadioStreamManager.applyState(worldPosition, streamUrl, volume);
    }

    public void applyClientSync(String url, String color, String text, int volume, boolean locked, boolean playing) {
        // This must not call markDirtyAndSync()
        this.streamUrl = (url == null) ? "" : url.trim();
        this.screenColor = sanitizeColor(color);
        this.screenText = sanitizeScreenText(text);
        this.volume = clamp(volume, 0, 10);
        this.locked = locked;
        this.playing = playing;

        // Now that fields are updated clientside, re-evaluate audio
        if (level != null && level.isClientSide) {
            clientApplyAudioState();
        }
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null && level.isClientSide) {
            clientApplyAudioState();
        }
    }

    @Override
    public void setRemoved() {
        if (level != null && level.isClientSide) {
            RadioStreamManager.applyState(worldPosition, "", 0);
        }
        super.setRemoved();
    }

    // ---- BE sync plumbing ----

    @Override
    public CompoundTag getUpdateTag() {
        return saveWithoutMetadata();
    }

    @Override
    public void handleUpdateTag(CompoundTag tag) {
        load(tag);
        clientApplyAudioState();
    }

    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public void onDataPacket(Connection net, ClientboundBlockEntityDataPacket pkt) {
        CompoundTag tag = pkt.getTag();
        if (tag != null) {
            load(tag);
            clientApplyAudioState();
        }
    }



    // Add to RadioBlockEntity

    public void cc_setStreamUrl(String url) {
        // TODO: set the same field your GUI uses
        this.streamUrl = url;

        cc_sync();
    }

    public void cc_start() {
        // TODO: do what your "Start" button does
        // Examples depending on your design:
        // this.playing = true;
        // or this.activeUrl = this.streamUrl;
        // or broadcast to linked speakers, etc.

        cc_sync();
    }

    public void cc_stop() {
        // TODO: do what your "Stop" button does
        // this.playing = false;
        // or this.activeUrl = "";
        cc_sync();
    }

    public int cc_getVolume() {
        return this.volume;
    }

    public void cc_setVolume(int vol) {
        if (vol < 0) vol = 0;
        if (vol > 10) vol = 10;
        this.volume = vol;

        cc_sync();
    }

    public int cc_getScreenColor() {
        // If you store hex string like "0AFF0A", parse to int and return 0xRRGGBB
        // If you already store int, return it directly.
        return Integer.parseInt(this.screenColor, 16);
    }

    public void cc_setScreenColor(int rgb) {
        // Store same format you already use. If you store string:
        this.screenColor = String.format("%06X", (rgb & 0xFFFFFF));

        cc_sync();
    }

    public String cc_getScreenText() {
        return this.screenText;
    }

    public void cc_setScreenText(String text) {
        this.screenText = text;
        cc_sync();
    }

    private void cc_sync() {
        setChanged();

        if (level != null && !level.isClientSide) {
            // If you already have a packet for syncing fields, call it here.
            // Otherwise at minimum:
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

}
