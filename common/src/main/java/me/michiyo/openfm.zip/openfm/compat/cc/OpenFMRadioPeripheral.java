package me.michiyo.openfm.compat.cc;

import dan200.computercraft.api.lua.LuaFunction;
import dan200.computercraft.api.peripheral.IPeripheral;
import me.michiyo.openfm.world.be.RadioBlockEntity;

import javax.annotation.Nullable;

/**
 * openfm_radio peripheral:
 * Mirrors the old OpenComputers API.
 */
public final class OpenFMRadioPeripheral implements IPeripheral {
    private final RadioBlockEntity radio;

    public OpenFMRadioPeripheral(RadioBlockEntity radio) {
        this.radio = radio;
    }

    @Override
    public String getType() {
        return "openfm_radio";
    }

    @Override
    public boolean equals(@Nullable IPeripheral other) {
        return other instanceof OpenFMRadioPeripheral o && o.radio == this.radio;
    }

    // ---------- Stream control ----------

    @LuaFunction(mainThread = true)
    public final void setURL(String url) {
        if (url == null) url = "";
        radio.cc_setStreamUrl(url);
    }

    @LuaFunction(mainThread = true)
    public final void start() {
        radio.cc_start();
    }

    @LuaFunction(mainThread = true)
    public final void stop() {
        radio.cc_stop();
    }

    @LuaFunction(mainThread = true)
    public final void volUp() {
        radio.cc_setVolume(radio.cc_getVolume() + 1);
    }

    @LuaFunction(mainThread = true)
    public final void volDown() {
        radio.cc_setVolume(radio.cc_getVolume() - 1);
    }

    @LuaFunction(mainThread = true)
    public final int getVol() {
        return radio.cc_getVolume();
    }

    // ---------- Screen ----------

    @LuaFunction(mainThread = true)
    public final void setScreenColor(int rgb) {
        // OC used 0xRRGGBB. Keep that.
        radio.cc_setScreenColor(rgb);
    }

    @LuaFunction(mainThread = true)
    public final int getScreenColor() {
        return radio.cc_getScreenColor();
    }

    @LuaFunction(mainThread = true)
    public final void setScreenText(String text) {
        if (text == null) text = "";
        radio.cc_setScreenText(text);
    }

    @LuaFunction(mainThread = true)
    public final String getScreenText() {
        return radio.cc_getScreenText();
    }
}
